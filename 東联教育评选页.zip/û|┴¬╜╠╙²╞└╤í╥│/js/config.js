let domain = 'http://cms.jspxedu.sydev:8080';
let config = {
	player : domain + '/rating/api/contestant_list',
	
}

