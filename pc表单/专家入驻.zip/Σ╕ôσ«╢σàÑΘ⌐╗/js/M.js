let data = [
    {
        goTo : "徐全杰",
        howMany : 200,
        people : [
            {
                name : "毛丕新",
                number : 200
            }
        ]
    },
    {
        goTo : "朱迪",
        howMany : 200,
        people : [
            {
                name : "毛丕新",
                number : 200
            }
        ]
    },
    {
        goTo : "王葵珍",
        howMany : 399,
        people : [
            {
                name : "毛丕新",
                number : 399
            }
        ]
    },
    {
        goTo : "李格",
        howMany : 600,
        people : [
            {
                name : "毛丕新",
                number : 300
            },
            {
                name : "闫慧玲",
                number : 300
            }
        ]
    }
];

console.log(data)