let domain = 'http://meet.dljy.com/ucenter';

let map = {
    expert : domain + "/api/enter_expert"
}
