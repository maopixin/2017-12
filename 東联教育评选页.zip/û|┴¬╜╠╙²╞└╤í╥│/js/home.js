function month(){
	this.child = $('#month-box li');
	this.num = this.child.length;
	this.now = 0;
	this._this = $('#month-box');
};
month.prototype.next = function(){
	if(this.now+1>=9) return;
	$('#month-box').css({
		'transform':'translate3d(-'+(++this.now)*282+'px,0,0)'
	});
};
month.prototype.pre = function(){
	if(this.now-1<0) return;
	$('#month-box').css({
		'transform':'translate3d(-'+(--this.now)*282+'px,0,0)'
	});
};
month.prototype.play = function(){
	$('#month-box').css({
		'transition':'all 0.5s'
	});
};
month.prototype.stop = function(){
	setTimeout(function(){
		$('#month-box').css({
			'transition':'0s'
		});
	},700);
};
month.prototype.init = function(){
	$('#month-box').css({
		'transform':'translate3d(0,0,0)'
	});
	this.play();
};

let month_fn = new month();
month_fn.init();
$('#next').click(function(){
	month_fn.next();
	$('#pre').css({
		'cursor':'pointer'
	});
	if(month_fn.now+1>=9){
		$(this).css({
			'cursor':'not-allowed'
		});
	}else{
		$(this).css({
			'cursor':'pointer'
		});
	};
});
$('#next').mouseover(function(){
	if(month_fn.now+1>=9){
		$(this).css({
			'cursor':'not-allowed'
		});
	}else{
		$(this).css({
			'cursor':'pointer'
		});
	}
})
$('#pre').click(function(){
	month_fn.pre();
	$('#next').css({
		'cursor':'pointer'
	});
	if(month_fn.now-1<0){
		$(this).css({
			'cursor':'not-allowed'
		});
	}else{
		$(this).css({
			'cursor':'pointer'
		});
	}
});
$('#pre').mouseover(function(){
	if(month_fn.now-1<0){
		$(this).css({
			'cursor':'not-allowed'
		});
	}else{
		$(this).css({
			'cursor':'pointer'
		});
	}
})
