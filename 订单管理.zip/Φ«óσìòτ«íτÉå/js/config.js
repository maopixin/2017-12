var main = 'http://meet.dljy.com';
var config = {
    indent : main + '/conference/api/get_purchase_pager'
};